package vistas.Comision;

import Controlador.Gestor;
import Model.Artista;
import Model.Artista_Reconocimiento;
import Model.Integrante;
import Model.Integrante_artista;
import Model.TipoDni;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;


public class abmIntegrantes extends javax.swing.JFrame {

    Gestor g = new Gestor();
    ArrayList<TipoDni> lstTipoDni = g.listarTipoDni();
    ArrayList<Artista_Reconocimiento> lstArtista ;
    ArrayList<Integrante_artista> lstIntegrante;
    ArrayList<Artista> lstComboArtista;
    ArrayList<Integer> listaId;
    ArrayList<Integer> listaIdIntegrante;
    DefaultComboBoxModel modelcombo = new DefaultComboBoxModel();
    DefaultComboBoxModel modelComboArtista = new DefaultComboBoxModel();
    DefaultListModel modelLista = new DefaultListModel();
        
    public abmIntegrantes() {
        
        
        try {
            this.lstArtista = g.listarArtista();
            this.lstComboArtista = g.ComboArtista();
            this.listaIdIntegrante = g.obtenerIdIntegrantes();
            
            
            initComponents();
            ActualizarLista();
            CargarComboTipoDni();
            CargarComboArtista();
            Desactivar();
        } catch (SQLException ex) {
            Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
        }
        

    }
       

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtNombreIntegrante = new javax.swing.JTextField();
        txtApellidoIntegrante = new javax.swing.JTextField();
        txtDocumento = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstIntegrantes = new javax.swing.JList<>();
        btnAgregar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        cboTipoDni = new javax.swing.JComboBox<>();
        rbtStaff = new javax.swing.JRadioButton();
        rbtMusico = new javax.swing.JRadioButton();
        rbtInvitado = new javax.swing.JRadioButton();
        rbtOtros = new javax.swing.JRadioButton();
        btnSeleccionar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        cboArtistas = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("LEGÜERO - INTEGRANTES");

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setFont(new java.awt.Font("Corbel", 1, 22)); // NOI18N
        jLabel1.setText("Ingrese los datos a guardar:");

        jLabel2.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel2.setText("Nombre :");

        jLabel3.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel3.setText("Apellido:");

        jLabel4.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel4.setText("Tipo de Documento:");

        jLabel5.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel5.setText("Documento:");

        jLabel6.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel6.setText("Dirección: ");

        jLabel7.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel7.setText("Tipo de Integrante:");

        txtNombreIntegrante.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N

        txtApellidoIntegrante.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N

        txtDocumento.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N
        txtDocumento.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        txtDireccion.setFont(new java.awt.Font("Corbel", 0, 12)); // NOI18N

        jScrollPane1.setBackground(new java.awt.Color(204, 255, 204));

        lstIntegrantes.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        lstIntegrantes.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        lstIntegrantes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lstIntegrantesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(lstIntegrantes);

        btnAgregar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnAgregar.setText("Guardar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnModificar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnNuevo.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        cboTipoDni.setBackground(new java.awt.Color(204, 255, 204));
        cboTipoDni.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        cboTipoDni.setMaximumRowCount(3);
        cboTipoDni.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tipo Documento" }));

        rbtStaff.setBackground(new java.awt.Color(204, 255, 204));
        buttonGroup1.add(rbtStaff);
        rbtStaff.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        rbtStaff.setText("Staff");

        rbtMusico.setBackground(new java.awt.Color(204, 255, 204));
        buttonGroup1.add(rbtMusico);
        rbtMusico.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        rbtMusico.setText("Músico");

        rbtInvitado.setBackground(new java.awt.Color(204, 255, 204));
        buttonGroup1.add(rbtInvitado);
        rbtInvitado.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        rbtInvitado.setText("Invitado");

        rbtOtros.setBackground(new java.awt.Color(204, 255, 204));
        buttonGroup1.add(rbtOtros);
        rbtOtros.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        rbtOtros.setText("Otros");

        btnSeleccionar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnSeleccionar.setText("Seleccionar");
        btnSeleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeleccionarActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel8.setText("Artista:");

        cboArtistas.setBackground(new java.awt.Color(204, 255, 204));
        cboArtistas.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        cboArtistas.setMaximumRowCount(3);
        cboArtistas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Artista" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(173, 173, 173)
                                        .addComponent(jLabel2))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING))))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtDireccion)
                                    .addComponent(txtDocumento)
                                    .addComponent(txtApellidoIntegrante)
                                    .addComponent(cboTipoDni, 0, 183, Short.MAX_VALUE)
                                    .addComponent(txtNombreIntegrante)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(rbtStaff, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(rbtMusico, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(rbtInvitado, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                                    .addComponent(rbtOtros, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cboArtistas, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(52, 52, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(btnNuevo)
                        .addGap(18, 18, 18)
                        .addComponent(btnAgregar)
                        .addGap(18, 18, 18)
                        .addComponent(btnModificar)
                        .addGap(18, 18, 18)
                        .addComponent(btnCancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnEliminar)
                        .addGap(211, 211, 211)
                        .addComponent(btnSeleccionar)))
                .addContainerGap(261, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(txtNombreIntegrante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtApellidoIntegrante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cboTipoDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtDocumento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(rbtStaff))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbtMusico)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbtInvitado)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbtOtros)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(cboArtistas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
                        
       if(Validar()){
           try {
               String nombre = txtNombreIntegrante.getText();
               String apellido = txtApellidoIntegrante.getText();
               int tipoDni = cboTipoDni.getSelectedIndex()+1;
               int dni = Integer.parseInt(txtDocumento.getText());
               String direccion = txtDireccion.getText();
               
               int id_tipoIntegrante = 0;
               if(rbtStaff.isSelected()){
                   id_tipoIntegrante = 1;
                   rbtMusico.setSelected(false);
                   rbtInvitado.setSelected(false);
                   rbtOtros.setSelected(false);
               }
               else{
                   if(rbtMusico.isSelected()){
                       id_tipoIntegrante = 2;
                       rbtStaff.setSelected(false);
                       rbtInvitado.setSelected(false);
                       rbtOtros.setSelected(false);
                   }
                   else{
                       if(rbtInvitado.isSelected()){
                           id_tipoIntegrante = 3;
                           rbtStaff.setSelected(false);
                           rbtMusico.setSelected(false);
                           rbtOtros.setSelected(false);
                       }
                       else{
                           if(rbtOtros.isSelected()){
                               id_tipoIntegrante = 4;
                               rbtStaff.setSelected(false);
                               rbtMusico.setSelected(false);
                               rbtInvitado.setSelected(false);
                               
                           }
                       }
                       
                   }
               }
                             
//               listaId = g.obtenerIdArtistas();
//               int id_art = listaId.get(cboArtistas.getSelectedIndex());
//               
//               lstComboArtista = g.ComboArtista();
//               
//               Artista a = new Artista();
//               int id_art = lstComboArtista.get(cboArtistas.getSelectedIndex()+1).getId_artista();
//               a = g.MostrarArtista(id_art);
//               
//                int asdfasdf =lstComboArtista.indexOf(a);
               
//                listaId = g.obtenerIdArtistas();
//                int id = listaId.get(cboArtistas.getSelectedIndex()+1);
//                lstComboArtista = g.ComboArtista();
//                int id_art = Integer.valueOf(lstComboArtista.get(id).getId_artista());
               
               
//               cboArtistas.getSelectedIndex()+1
//               listaId = g.obtenerIdArtistas();               
//               int id_art = listaId.get();
//               
//               lstComboArtista = g.ComboArtista();
//               int id = lstComboArtista.get(id_art).getId_artista();
//               
//               Artista a = new Artista();
//               a = g.MostrarArtista(id);
//               int id_artista = a.getId_artista();
                       
                int id_artista = cboArtistas.getSelectedIndex()+1;
               
                
               Integrante i = new Integrante(nombre, apellido, tipoDni, dni, direccion, id_tipoIntegrante, id_artista);
               
               
               g.agregarIntegrante(i);
               JOptionPane.showMessageDialog(this, "Integrante Cargado Correctamente");
               ActualizarLista();
               Limpiar();
               Desactivar();
               listaId = g.obtenerIdIntegrantes();
           } catch (SQLException ex) {
               Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
           }
           
       }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        if(Validar()){
            try {
                
                listaId = g.obtenerIdIntegrantes();
                int id_int = listaId.get(lstIntegrantes.getSelectedIndex());
                Integrante i = new Integrante();
                
            
                i = g.MostrarIntegrante(id_int);
                int id_integrante = i.getId_integrante();
                String nombre = txtNombreIntegrante.getText();
                String apellido = txtApellidoIntegrante.getText();
                int tipoDni = cboTipoDni.getSelectedIndex()+1;
                int dni = Integer.parseInt(txtDocumento.getText());
                String direccion = txtDireccion.getText();
                
                int id_tipoIntegrante = 0;
                if(rbtStaff.isSelected()){
                    id_tipoIntegrante = 1;
                    rbtMusico.setSelected(false);
                    rbtInvitado.setSelected(false);
                    rbtOtros.setSelected(false);
                }
                else{
                    if(rbtMusico.isSelected()){
                        id_tipoIntegrante = 2;
                        rbtStaff.setSelected(false);
                        rbtInvitado.setSelected(false);
                        rbtOtros.setSelected(false);                        
                    }
                    else{
                        if(rbtInvitado.isSelected()){
                            id_tipoIntegrante = 3;
                            rbtStaff.setSelected(false);
                            rbtMusico.setSelected(false);
                            rbtOtros.setSelected(false);
                        }
                        else{
                            if(rbtOtros.isSelected()){
                                id_tipoIntegrante = 4;
                                rbtStaff.setSelected(false);
                                rbtMusico.setSelected(false);
                                rbtInvitado.setSelected(false);
                                
                            }
                        }
                        
                    }
                }
                
                listaId = g.obtenerIdArtistas();               
                int id_art = listaId.get(cboArtistas.getSelectedIndex());
               
                lstComboArtista = g.ComboArtista();
                int id = lstComboArtista.get(id_art).getId_artista();
               
                Artista a = new Artista();
                a = g.MostrarArtista(id);
                int id_artista = a.getId_artista();
                
                
                g.modificarIntegrante(new Integrante(id_integrante, nombre, apellido, tipoDni, dni, direccion, id_tipoIntegrante,id_artista));
                JOptionPane.showMessageDialog(this, "Integrante Actualizado Correctamente");
                ActualizarLista();
                Limpiar();
                Desactivar();
            } catch (SQLException ex) {
                Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
            }
           
       }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        try {
            Limpiar();
            Desactivar();
            listaId = g.obtenerIdIntegrantes();
        } catch (SQLException ex) {
            Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        ActivarNuevo();
        Limpiar();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void lstIntegrantesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lstIntegrantesMouseClicked
        MostrarDatos(lstIntegrantes.getSelectedIndex());
            
        
    }//GEN-LAST:event_lstIntegrantesMouseClicked

    private void btnSeleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeleccionarActionPerformed
        ActivarModificar();
    }//GEN-LAST:event_btnSeleccionarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        
        try {
            
            listaId = g.obtenerIdIntegrantes();
            int id_int = listaId.get(lstIntegrantes.getSelectedIndex());
            
            Integrante i = new Integrante();
            
            
            
            i = g.MostrarIntegrante(id_int);
            
            int id_integrante = i.getId_integrante();
                String nombre = txtNombreIntegrante.getText();
                String apellido = txtApellidoIntegrante.getText();
                int tipoDni = cboTipoDni.getSelectedIndex()+1;
                int dni = Integer.parseInt(txtDocumento.getText());
                String direccion = txtDireccion.getText();
                
                int id_tipoIntegrante = 0;
                if(rbtStaff.isSelected()){
                    id_tipoIntegrante = 1;
                    rbtMusico.setSelected(false);
                    rbtInvitado.setSelected(false);
                    rbtOtros.setSelected(false);
                }
                else{
                    if(rbtMusico.isSelected()){
                        id_tipoIntegrante = 2;
                        rbtStaff.setSelected(false);
                        rbtInvitado.setSelected(false);
                        rbtOtros.setSelected(false);                        
                    }
                    else{
                        if(rbtInvitado.isSelected()){
                            id_tipoIntegrante = 3;
                            rbtStaff.setSelected(false);
                            rbtMusico.setSelected(false);
                            rbtOtros.setSelected(false);
                        }
                        else{
                            if(rbtOtros.isSelected()){
                                id_tipoIntegrante = 4;
                                rbtStaff.setSelected(false);
                                rbtMusico.setSelected(false);
                                rbtInvitado.setSelected(false);
                                
                            }
                        }
                        
                    }
                }
                listaId = g.obtenerIdArtistas();               
                int id_art = listaId.get(cboArtistas.getSelectedIndex());
               
                lstComboArtista = g.ComboArtista();
                int id = lstComboArtista.get(id_art).getId_artista();
               
                Artista a = new Artista();
                a = g.MostrarArtista(id);
                int id_artista = a.getId_artista();
                
            g.eliminarIntegrante(new Integrante(id_integrante, nombre, apellido, tipoDni, dni, direccion, id_tipoIntegrante,id_artista));
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito");
            ActualizarLista();
            Limpiar();
            Desactivar();

        } catch (SQLException ex) {
            Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btnEliminarActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(abmIntegrantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(abmIntegrantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(abmIntegrantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(abmIntegrantes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new abmIntegrantes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSeleccionar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cboArtistas;
    private javax.swing.JComboBox<String> cboTipoDni;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> lstIntegrantes;
    private javax.swing.JRadioButton rbtInvitado;
    private javax.swing.JRadioButton rbtMusico;
    private javax.swing.JRadioButton rbtOtros;
    private javax.swing.JRadioButton rbtStaff;
    private javax.swing.JTextField txtApellidoIntegrante;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtDocumento;
    private javax.swing.JTextField txtNombreIntegrante;
    // End of variables declaration//GEN-END:variables
    
    
    private void Limpiar() {
        txtNombreIntegrante.setText("");
        txtApellidoIntegrante.setText("");
        cboTipoDni.setSelectedIndex(-1);
        txtDocumento.setText("");
        txtDireccion.setText("");
        rbtStaff.setSelected(false);
        rbtMusico.setSelected(false);
        rbtInvitado.setSelected(false);
        rbtOtros.setSelected(false);
        cboArtistas.setSelectedIndex(-1);
    }

    private boolean Validar() {
        if(txtNombreIntegrante.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe ingresar un Nombre.");
            return false;
        }
        if(txtApellidoIntegrante.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe ingresar un Apellido.");
            return false;
        }
        if(cboTipoDni.getSelectedIndex()== -1){
            JOptionPane.showMessageDialog(this, "Debe seleccionar un Tipo de DNI.");
            return false;
        }
        if(txtDocumento.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe ingresar un N° de Documento.");
            return false;
        }
        
        if(txtDireccion.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this, "Debe ingresar una Dirección.");
            return false;
        }
        if(!rbtStaff.isSelected() ){
            if(!rbtMusico.isSelected()){
                if(!rbtInvitado.isSelected())
                {
                    if(!rbtOtros.isSelected())
                    {
                        JOptionPane.showMessageDialog(this, "Debe Seleccionar un Tipo de Integrante.");
                        return false;
                    }
                    
                }
            }            
        }
        if(cboArtistas.getSelectedIndex() == -1)
        {
            JOptionPane.showMessageDialog(this, "Debe Seleccionar un Artista");
            return false;
        }
    
        return true;
    }
    
    private void CargarComboTipoDni(){
        
        modelcombo.removeAllElements();
        
        for (TipoDni tipoDni : lstTipoDni) {
            modelcombo.addElement(tipoDni);
        }
        cboTipoDni.setModel(modelcombo);
    }
    private void CargarComboArtista(){
        
        modelComboArtista.removeAllElements();
        
        for (Artista art : lstComboArtista) {
            modelComboArtista.addElement(art);
        }
        cboArtistas.setModel(modelComboArtista);
    }
    
    private void ActualizarLista(){ 
        
        lstIntegrante = g.listarIntegrantes();
        modelLista.removeAllElements();
        for (Integrante_artista ipt : lstIntegrante) {
            
            modelLista.addElement(ipt);
        }
        lstIntegrantes.setModel(modelLista);
        
       
    }
    
    private void Desactivar(){
        
        txtNombreIntegrante.setEnabled(false);
        txtApellidoIntegrante.setEnabled(false);
        cboTipoDni.setEnabled(false);
        cboTipoDni.setSelectedIndex(-1);
        txtDocumento.setEnabled(false);
        txtDireccion.setEnabled(false);
        rbtStaff.setEnabled(false);
        rbtMusico.setEnabled(false);
        rbtInvitado.setEnabled(false);
        rbtOtros.setEnabled(false);
        cboArtistas.setEnabled(false);
        cboArtistas.setSelectedIndex(-1);
        btnAgregar.setEnabled(false);
        btnCancelar.setEnabled(false);  
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(true);
        btnNuevo.setEnabled(true);
    
    }
    
    
    private void ActivarNuevo(){
        
        txtNombreIntegrante.setEnabled(true);
        txtApellidoIntegrante.setEnabled(true);
        cboTipoDni.setEnabled(true);
        cboTipoDni.setSelectedIndex(0);
        txtDocumento.setEnabled(true);
        txtDireccion.setEnabled(true);
        rbtStaff.setEnabled(true);
        rbtMusico.setEnabled(true);
        rbtInvitado.setEnabled(true);
        rbtOtros.setEnabled(true);
        cboArtistas.setEnabled(true);
        cboArtistas.setSelectedIndex(0);
        btnAgregar.setEnabled(true);
        btnCancelar.setEnabled(true);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnNuevo.setEnabled(false);
    
    }
    
     private void ActivarModificar(){
        
        txtNombreIntegrante.setEnabled(true);
        txtApellidoIntegrante.setEnabled(true);
        cboTipoDni.setEnabled(true);
        cboTipoDni.setSelectedIndex(0);
        txtDocumento.setEnabled(true);
        txtDireccion.setEnabled(true);
        rbtStaff.setEnabled(true);
        rbtMusico.setEnabled(true);
        rbtInvitado.setEnabled(true);
        rbtOtros.setEnabled(true);
        cboArtistas.setEnabled(true);
        cboArtistas.setSelectedIndex(0);
        btnAgregar.setEnabled(false);
        btnCancelar.setEnabled(true);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(true);
        btnNuevo.setEnabled(false);
    
    }
    
    private void MostrarDatos(int posicion)
    {
        try {
            listaIdIntegrante = g.obtenerIdIntegrantes();
            int id_int = listaIdIntegrante.get(posicion);
            
            for (Integrante_artista ipt : lstIntegrante) {
                if(id_int == ipt.getId_integrante()){
                    Integrante i = new Integrante();                        
                    i = g.MostrarIntegrante(ipt.getId_integrante());
                    
//                    int id_artista = i.getId_artista();
//                    
//                    Artista a = new Artista();
//                    a = g.MostrarArtista(id_artista);
//                    
//                    
//                    
//                    listaId = g.obtenerIdArtistas();
//                    int pos = listaId.get(a.getId_artista());
//                    
//                    lstComboArtista = g.ComboArtista();
//                    int pos_com = lstComboArtista.get(pos).getId_artista();
//                    cboArtistas.setSelectedIndex((pos_com)-1);                
                    
                    
                    txtNombreIntegrante.setText(i.getNombre());
                    txtApellidoIntegrante.setText(i.getApellido());
                    cboTipoDni.setSelectedIndex(i.getId_tipoDni()-1);
                    txtDocumento.setText(String.valueOf(i.getDni()));
                    txtDireccion.setText(i.getDireccion());
                    if(i.getId_tipoIntegrante() == 1){
                        rbtStaff.setSelected(true);
                    }else{
                        if(i.getId_tipoIntegrante() == 2){
                            rbtMusico.setSelected(true);
                        }else{
                            if(i.getId_tipoIntegrante() == 3){
                                rbtInvitado.setSelected(true);
                            }else{
                                if(i.getId_tipoIntegrante() == 4)
                                {
                                    rbtOtros.setSelected(true);
                                }
                            }
                        }
                    }
                    
                    
               
                    
               
                    
                    
                    
                    
                    
                    
                    
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
