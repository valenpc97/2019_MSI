
package vistas.Comision;

import Controlador.Gestor;
import Model.Artista;
import Model.Noche;
import Model.Presentacion;
import Model.Presentacion_noche;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;


public class PresentacionVen extends javax.swing.JFrame {

    Gestor g = new Gestor();
    DefaultComboBoxModel modelcombo = new DefaultComboBoxModel();
    DefaultComboBoxModel modelcombo2 = new DefaultComboBoxModel();
    ArrayList<Noche> lstPresentacion;
    ArrayList<Artista> lstArtistas;
    DefaultListModel modelLista = new DefaultListModel();
    ArrayList<Presentacion_noche> presentaciones = g.ListarPresentacion();
    public PresentacionVen() {
      
              
        try {
            this.lstPresentacion = g.listarNoche();
            lstArtistas = g.ComboArtista();
            initComponents();
            CargarComboNoche();
            CargarComboArtistas();
            actualizarTabla();
            Desactivar();
            cargarTabla(presentaciones);        
            ocultarBotones();
            tblPresentaciones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
       
            tblPresentaciones.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
               
                JOptionPane.showMessageDialog(null, tblPresentaciones.getSelectedRow());                
                mostrarBotones();
            }
        });
        } catch (SQLException ex) {
            Logger.getLogger(PresentacionVen.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Image getIconImage() {
        Image logo = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/logoLegueroBombo.png"));

        return logo;
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblPresentaciones = new javax.swing.JTable();
        cboNoche = new javax.swing.JComboBox<>();
        txtHorario = new javax.swing.JTextField();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        cboArtistas = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("LEGÜERO - PRESENTACION");
        setIconImage(getIconImage());

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel2.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel2.setText("Selecione Noche: ");

        jLabel3.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel3.setText("Ingrese Horario:");

        btnNuevo.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnGuardar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Corbel", 1, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Listado de  Presentaciones de la Noche Seleccionada");
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        tblPresentaciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Horario", "Artista", "Noche"
            }
        ));
        jScrollPane2.setViewportView(tblPresentaciones);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(211, 211, 211)))
        );

        cboNoche.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N

        txtHorario.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N

        btnEditar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        cboArtistas.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel5.setText("Selecione Artista: ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(383, 383, 383)
                        .addComponent(btnNuevo)
                        .addGap(53, 53, 53)
                        .addComponent(btnGuardar)
                        .addGap(54, 54, 54)
                        .addComponent(btnCancelar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(326, 326, 326)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 472, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5))
                                .addGap(41, 41, 41)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cboNoche, 0, 116, Short.MAX_VALUE)
                                    .addComponent(txtHorario)
                                    .addComponent(cboArtistas, 0, 116, Short.MAX_VALUE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(452, 452, 452)
                        .addComponent(btnEditar)
                        .addGap(81, 81, 81)
                        .addComponent(btnEliminar)))
                .addContainerGap(369, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboArtistas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cboNoche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNuevo)
                    .addComponent(btnGuardar)
                    .addComponent(btnCancelar))
                .addGap(36, 36, 36)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEditar)
                    .addComponent(btnEliminar))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        actualizarTabla();
        ActivarNuevo();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        if(Validar())
        {
            try {                              
                
                int id_artista = cboArtistas.getSelectedIndex()+1;
                String horarioComienzo = txtHorario.getText();
                int id_noche = cboNoche.getSelectedIndex()+1;               
                
                g.agregarPresentacion(new Presentacion(id_artista, horarioComienzo, id_noche));
                JOptionPane.showMessageDialog(this, "Presentacion Cargada Correctamente");
                actualizarTabla();
                Limpiar();
                Desactivar();
                
            } catch (SQLException ex) {
                Logger.getLogger(PresentacionVen.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int idDePersonaAModificar = (int) tblPresentaciones.getValueAt(tblPresentaciones.getSelectedRow(), 0);
        ActivarEditar();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        try {
            int idPresentacionesAEliminar = (int) tblPresentaciones.getValueAt(tblPresentaciones.getSelectedRow(), 0);
            
            
            int filasAfectadas = g.EliminarPresentacionesPorId(idPresentacionesAEliminar);
            if (filasAfectadas > 0) {
                JOptionPane.showMessageDialog(null, "Registro eliminado con éxito");
                
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo eliminar el registro");
            }
        } catch (SQLException ex) {
            Logger.getLogger(PresentacionVen.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        Limpiar();
        Desactivar();
    }//GEN-LAST:event_btnCancelarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PresentacionVen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PresentacionVen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PresentacionVen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PresentacionVen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PresentacionVen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> cboArtistas;
    private javax.swing.JComboBox<String> cboNoche;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblPresentaciones;
    private javax.swing.JTextField txtHorario;
    // End of variables declaration//GEN-END:variables

    private void CargarComboNoche(){
        
        modelcombo.removeAllElements();
        
        for (Noche n : lstPresentacion) {
            modelcombo.addElement(n);
        }
        cboNoche.setModel(modelcombo);
    }
    private void CargarComboArtistas(){
        
        modelcombo2.removeAllElements();
        
        for (Artista a : lstArtistas) {
            modelcombo2.addElement(a);
        }
        cboArtistas.setModel(modelcombo2);
    }
    private boolean Validar() {
        
        if(cboArtistas.getSelectedIndex()== -1){
            JOptionPane.showMessageDialog(this, "Debe seleccionar un Artistas");
            return false;
        }
        if(txtHorario.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe ingresar un Horiario");
            return false;
        }  
        if(cboNoche.getSelectedIndex()== -1){
            JOptionPane.showMessageDialog(this, "Debe seleccionar una Noche");
            return false;
        }
            
        return true;
    }
    private void Limpiar() {
        
        cboArtistas.setSelectedIndex(-1);
        txtHorario.setText("");   
        cboNoche.setSelectedIndex(-1);
                
    }
    private void Desactivar(){
        
        cboArtistas.setEnabled(false);
        txtHorario.setEnabled(false);
        cboNoche.setEnabled(false);
        btnCancelar.setEnabled(false);  
        btnGuardar.setEnabled(false);
        btnNuevo.setEnabled(true);
       
    
    }
    
    private void ActivarNuevo(){
        
        cboArtistas.setEnabled(true);
        txtHorario.setEnabled(true);
        cboNoche.setEnabled(true);
        btnCancelar.setEnabled(true);  
        btnGuardar.setEnabled(true);
        btnNuevo.setEnabled(false);
        
    
    }
    
     private void ActivarEditar(){
        
        cboArtistas.setEnabled(true);
        txtHorario.setEnabled(true);
        cboNoche.setEnabled(true);
        btnCancelar.setEnabled(true);  
        btnGuardar.setEnabled(true);
        btnNuevo.setEnabled(false);
       
    
    }
     
     
     private void mostrarBotones() {
        btnEditar.setVisible(true);
        btnEliminar.setVisible(true);
    }

    private void ocultarBotones() {
        btnEditar.setVisible(false);
        btnEliminar.setVisible(false);
    }
    
    private void cargarTabla(ArrayList<Presentacion_noche> presentaciones ) {
        DefaultTableModel dtm = new DefaultTableModel();
        //String[] nombreDeColumnas = new String[4];
        //nombreDeColumnas[0] = "id";
        //nombreDeColumnas[1] = "nombre";
        //nombreDeColumnas[2] = "apellido";
        //nombreDeColumnas[3] = "edad";
        //Lo que está comentado es equivalente a lo siguiente
        String[] nombreDeColumnas = {"ID" , "Horario", "Artista", "Noche"};
        dtm.setColumnIdentifiers(nombreDeColumnas);

        for (Presentacion_noche pn : presentaciones) {
            Object[] row = {pn.getId_presentacion(),pn.getHorarioComienzo(), pn.getArtista(), pn.getNoche()};
            dtm.addRow(row);
        }

        tblPresentaciones.setModel(dtm);
    }
    private void actualizarTabla() {
        //Actualizamos la tabla trayendo de nuevo los registros desde la BD
        cargarTabla(g.ListarPresentacion());
        //Como se borra la selección actual desabilitamos los botones
        ocultarBotones();
    }

}

