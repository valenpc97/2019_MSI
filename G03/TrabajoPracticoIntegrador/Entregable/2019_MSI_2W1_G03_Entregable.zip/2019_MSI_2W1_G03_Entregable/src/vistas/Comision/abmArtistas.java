
package vistas.Comision;

import Controlador.Gestor;
import Model.Artista;
import Model.Artista_Reconocimiento;
import java.util.Date;
import Model.Integrante_artista;
import Model.Reconocimiento;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionListener;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.jdesktop.swingx.plaf.basic.CalendarState;

public class abmArtistas extends javax.swing.JFrame {
    
    Gestor g = new Gestor();
    ArrayList<Reconocimiento> lstReconocimiento = g.listarReconocimiento();
    ArrayList<Artista_Reconocimiento> lstArtista = g.listarArtista();
    ArrayList<Integrante_artista> lstIntegrante = g.listarIntegrantes();
    ArrayList<Integer> listaId = g.obtenerIdArtistas();
    ArrayList<Integer> listaIdIntegrante = g.obtenerIdIntegrantes();
    DefaultComboBoxModel modelcombo = new DefaultComboBoxModel();
    DefaultComboBoxModel modelcombo2 = new DefaultComboBoxModel();
    DefaultListModel modelLista = new DefaultListModel();
     

    
    public abmArtistas() throws SQLException {
        
        initComponents();
        ActualizarLista();
        CargarComboReconocimiento();        
        Desactivar();
        
        
    }
    public Image getIconImage() 
    {
        Image logo = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/logoLegueroBombo.png"));

        return logo;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtNombreArt = new javax.swing.JTextField();
        txtHistoria = new javax.swing.JTextField();
        cboRec = new javax.swing.JComboBox<>();
        btnAgregar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        btnSeleccionar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstArtistas = new javax.swing.JList<>();
        btnGenerarReporte = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        dtpFechaInicio = new org.jdesktop.swingx.JXDatePicker();
        dtpFechaFin = new org.jdesktop.swingx.JXDatePicker();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("LEGÜERO - ARTISTAS");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImage(getIconImage());

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setFont(new java.awt.Font("Corbel", 1, 22)); // NOI18N
        jLabel1.setText("Ingrese los datos a guardar:");

        jLabel2.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel2.setText("Nombre Artistico:");

        jLabel3.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel3.setText("Fecha de Inicio Disponible:");

        jLabel4.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel4.setText("Fecha de Fin Disponible:");

        jLabel5.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel5.setText("Reconocimiento:");

        jLabel6.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel6.setText("Historia:");

        cboRec.setBackground(new java.awt.Color(204, 255, 204));
        cboRec.setFont(new java.awt.Font("Corbel", 1, 12)); // NOI18N
        cboRec.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Reconocimiento" }));

        btnAgregar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnAgregar.setText("Guardar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnModificar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));

        btnSeleccionar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnSeleccionar.setText("Seleccionar");
        btnSeleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeleccionarActionPerformed(evt);
            }
        });

        lstArtistas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black));
        lstArtistas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lstArtistasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(lstArtistas);

        btnGenerarReporte.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnGenerarReporte.setText("Generar Reporte");
        btnGenerarReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarReporteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(btnSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnGenerarReporte))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(79, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(58, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGenerarReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
        );

        btnNuevo.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(135, 135, 135)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel6)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel2))
                                    .addGap(50, 50, 50)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtHistoria, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                                        .addComponent(txtNombreArt, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                                        .addComponent(dtpFechaInicio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(dtpFechaFin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(44, 44, 44)
                                    .addComponent(jLabel5)
                                    .addGap(50, 50, 50)
                                    .addComponent(cboRec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel3)
                            .addGap(166, 166, 166)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(btnNuevo)
                        .addGap(18, 18, 18)
                        .addComponent(btnAgregar)
                        .addGap(18, 18, 18)
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnCancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnEliminar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtNombreArt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(dtpFechaInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(dtpFechaFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(cboRec, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtHistoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        ActivarNuevo();
        Limpiar();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        try {
            Limpiar();
            Desactivar();
            listaId = g.obtenerIdArtistas();
        } catch (SQLException ex) {
            Logger.getLogger(abmArtistas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        if(Validar()){
            try {
                
                listaId = g.obtenerIdArtistas();
                int id_art = listaId.get(lstArtistas.getSelectedIndex());
                Artista a = new Artista();
                       
                a = g.MostrarArtista(id_art);
                int id_artista = a.getId_artista();
                String artista = txtNombreArt.getText();
                java.sql.Date fechaInicio = new java.sql.Date(dtpFechaInicio.getDate().getTime());
                java.sql.Date fechaFin = new java.sql.Date(dtpFechaFin.getDate().getTime());
                int id_reconocimiento = cboRec.getSelectedIndex()+1;
                String historia = txtHistoria.getText();
                
                
                g.modificarArtista(new Artista(id_artista, artista, fechaInicio, fechaFin, id_reconocimiento, historia));
                JOptionPane.showMessageDialog(this, "Artista Actualizado Correctamente");
                ActualizarLista();
                Limpiar();
                Desactivar();
            } catch (SQLException ex) {
                Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
            }
           
       }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed

        if(Validar()){
            try {
                              
                
                String nombre = txtNombreArt.getText();                
                java.sql.Date fechaInicio = new java.sql.Date(dtpFechaInicio.getDate().getTime());
                java.sql.Date fechaFin = new java.sql.Date(dtpFechaFin.getDate().getTime());                
                int id_reconocimiento = cboRec.getSelectedIndex()+1;
                String historia = txtHistoria.getText();
                
                
                g.agregarArtista(new Artista(nombre,fechaInicio,fechaFin,id_reconocimiento,historia));
                JOptionPane.showMessageDialog(this, "Artista Cargado Correctamente");
                ActualizarLista();
                Limpiar();
                Desactivar();
                listaId = g.obtenerIdArtistas();
            } catch (SQLException ex) {
                Logger.getLogger(abmArtistas.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnSeleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeleccionarActionPerformed
        ActivarModificar();
    }//GEN-LAST:event_btnSeleccionarActionPerformed

    private void lstArtistasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lstArtistasMouseClicked
        MostrarDatos(lstArtistas.getSelectedIndex());
    }//GEN-LAST:event_lstArtistasMouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        try {
            
            listaId = g.obtenerIdArtistas();
            int id_art = listaId.get(lstArtistas.getSelectedIndex());
                
            Artista a = new Artista();
                       
                
            
            a = g.MostrarArtista(id_art);
            int id_artista = a.getId_artista();
            String artista = txtNombreArt.getText();
            java.sql.Date fechaInicio = new java.sql.Date(dtpFechaInicio.getDate().getTime());
            java.sql.Date fechaFin = new java.sql.Date(dtpFechaFin.getDate().getTime());
            int id_reconocimiento = cboRec.getSelectedIndex()+1;
            String historia = txtHistoria.getText();
            
            
            g.EliminarArtista(new Artista(id_artista, artista,  fechaInicio, fechaFin, id_reconocimiento, historia));
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito");
            ActualizarLista();
            Limpiar();
            Desactivar();
                 
            

        } catch (SQLException ex) {
            Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnGenerarReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarReporteActionPerformed
        try {
            //        try {
//            ActivarModificar();
//            g.Reporte(null);
//        } catch (JRException ex) {
//            Logger.getLogger(abmArtistas.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (SQLException ex) {
//            Logger.getLogger(abmArtistas.class.getName()).log(Level.SEVERE, null, ex);
//        }
            JasperReport reporte = JasperCompileManager.compileReport("D:\\TECNICATURA\\SEGUNDO AÑO\\SEGUNDO CUATRIMESTRE\\METODOLOGIA DE SISTEMAS\\PROGRAMA\\FestivalCodigo2\\src\\Model\\reporteArtistas.jrxml");
            JasperPrint print = JasperFillManager.fillReport(reporte, null, conec);
            JOptionPane.showMessageDialog(null, print);
        } catch (JRException ex) {
            Logger.getLogger(abmArtistas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnGenerarReporteActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(abmArtistas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(abmArtistas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(abmArtistas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(abmArtistas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new abmArtistas().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(abmArtistas.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGenerarReporte;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSeleccionar;
    private javax.swing.JComboBox<String> cboRec;
    private org.jdesktop.swingx.JXDatePicker dtpFechaFin;
    private org.jdesktop.swingx.JXDatePicker dtpFechaInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> lstArtistas;
    private javax.swing.JTextField txtHistoria;
    private javax.swing.JTextField txtNombreArt;
    // End of variables declaration//GEN-END:variables

    Connection conec = DriverManager.getConnection("jdbc:sqlserver://Emma-PC\\SQLEXPRESS:1433;databaseName=tp_metodologia_festival2", "sa", "123456" );
    
    private void Limpiar() {
        
        txtNombreArt.setText("");
//        dtpFechaInicio.setDate();
//        dtpFechaFin.setDate(date);
        cboRec.setSelectedIndex(-1);
        txtHistoria.setText("");
        
                
    }
    
    private boolean Validar() {
        
        
        java.sql.Date date1 = new java.sql.Date (dtpFechaInicio.getDate().getTime());
        java.sql.Date date2 = new java.sql.Date (dtpFechaFin.getDate().getTime());
        
                
        if(txtNombreArt.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe ingresar un Nombre Artistico");
            return false;
        }
        if(dtpFechaInicio.getDate() == null){
            JOptionPane.showMessageDialog(this, "Debe ingresar una fecha de inicio de disponibilidad");
            return false;
        }
        if(dtpFechaFin.getDate()== null){
            JOptionPane.showMessageDialog(this, "Debe ingresar una fecha de fin de disponibilidad");
            return false;
        }
        if(date1.compareTo(date2) > 0){
            JOptionPane.showMessageDialog(this, "Debe seleccionar una fecha posterior a la fecha de Inicio.");
            return false;
        }
        if(cboRec.getSelectedIndex()== -1){
            JOptionPane.showMessageDialog(this, "Debe seleccionar un Alcance de Reconocimiento");
            return false;
        }
        if(txtHistoria.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe ingresar una descripcion breve de la historia del artista");
            return false;
        }
        
            
        return true;
    }
    
    private void ActualizarLista() throws SQLException{
        lstArtista = g.listarArtista();
        modelLista.removeAllElements();
        for (Artista_Reconocimiento air : lstArtista) {

            modelLista.addElement(air);
        }
        lstArtistas.setModel(modelLista);
        
    }   
    
    private void CargarComboReconocimiento(){
        modelcombo.removeAllElements();
        
        for (Reconocimiento rec : lstReconocimiento) {
            modelcombo.addElement(rec);
        }
        cboRec.setModel(modelcombo);
    }
    
    private void Desactivar(){
        
        txtNombreArt.setEnabled(false);
        dtpFechaInicio.setEnabled(false);
        dtpFechaFin.setEnabled(false);
        cboRec.setSelectedIndex(-1);
        cboRec.setEnabled(false);        
        txtHistoria.setEnabled(false);
        btnAgregar.setEnabled(false);
        btnCancelar.setEnabled(false);  
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(true);
        btnNuevo.setEnabled(true);
    
    }
    
    private void ActivarNuevo(){
        
        txtNombreArt.setEnabled(true);
        dtpFechaInicio.setEnabled(true);
        dtpFechaFin.setEnabled(true);
        cboRec.setSelectedIndex(0);
        cboRec.setEnabled(true);        
        txtHistoria.setEnabled(true);
        btnAgregar.setEnabled(true);
        btnCancelar.setEnabled(true);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnNuevo.setEnabled(false);
    
    }
    
     private void ActivarModificar(){
        
        txtNombreArt.setEnabled(true);
        dtpFechaInicio.setEnabled(true);
        dtpFechaFin.setEnabled(true);
        cboRec.setSelectedIndex(0);
        cboRec.setEnabled(true);        
        txtHistoria.setEnabled(true);
        btnAgregar.setEnabled(false);
        btnCancelar.setEnabled(true);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(true);
        btnNuevo.setEnabled(false);
    
    }
    private void MostrarDatos(int posicion) 
    {
                
        try {           
            int id_art = listaId.get(posicion);
                       
            for (Artista_Reconocimiento art : lstArtista) {
                if(id_art == art.getId_artista()){
                    Artista a = new Artista();
                    a = g.MostrarArtista(art.getId_artista());
//                    Integrante i = new Integrante();
//                    
//                    int id_int = listaIdIntegrante.get(cboIntegrantes.getSelectedIndex()+1);
//                    i = g.MostrarIntegrante(id_int);
//                    
//                    a.setId_integrante(i.getId_integrante());
                           
                    txtNombreArt.setText(a.getArtista());
                    dtpFechaInicio.setDate(a.getFechaInicioDisponibilidad());
                    dtpFechaFin.setDate(a.getFechaFinDisponibilidad());
                    cboRec.setSelectedIndex(a.getId_reconocimiento()-1);
                    txtHistoria.setText(a.getHistoria());
                    
                }                
            }               
            
        } catch (SQLException ex) {
            Logger.getLogger(abmArtistas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
