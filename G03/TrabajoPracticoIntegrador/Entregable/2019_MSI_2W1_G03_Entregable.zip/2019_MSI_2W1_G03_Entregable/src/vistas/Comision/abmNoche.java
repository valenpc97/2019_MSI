
package vistas.Comision;

import Controlador.Gestor;
import Model.Noche;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;


public class abmNoche extends javax.swing.JFrame {

    Gestor g = new Gestor();
    ArrayList<Noche> lstNoche = g.listarNoche();
    ArrayList<Integer> listaId = g.obtenerIdNoches();
    DefaultListModel modelLista = new DefaultListModel();
    public abmNoche() throws SQLException {
        initComponents();
        ActualizarLista();
        Desactivar();
        
    }

    public Image getIconImage() {
        Image logo = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/logoLegueroBombo.png"));

        return logo;
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        txtPrecioXNoche = new javax.swing.JTextField();
        btnCancelar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnSeleccionar = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        dtpFechaNoche = new org.jdesktop.swingx.JXDatePicker();
        jScrollPane2 = new javax.swing.JScrollPane();
        lstNoches = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("LEGÜERO - NOCHES");
        setIconImage(getIconImage());

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel1.setFont(new java.awt.Font("Corbel", 1, 22)); // NOI18N
        jLabel1.setText("Ingrese los datos a guardar:");

        jLabel2.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel2.setText("Fecha:");

        jLabel3.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel3.setText("Descripcion:");

        jLabel4.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        jLabel4.setText("Precio de la Noche:");

        txtDescripcion.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N

        txtPrecioXNoche.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N

        btnCancelar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnModificar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnSeleccionar.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnSeleccionar.setText("Seleccionar");
        btnSeleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSeleccionarActionPerformed(evt);
            }
        });

        btnNuevo.setFont(new java.awt.Font("Corbel", 1, 14)); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        lstNoches.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lstNochesMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(lstNoches);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnNuevo, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                                    .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE))
                                .addGap(8, 8, 8)
                                .addComponent(btnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(49, 49, 49)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtDescripcion)
                                    .addComponent(txtPrecioXNoche, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
                                    .addComponent(dtpFechaNoche, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addComponent(btnSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 402, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dtpFechaNoche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPrecioXNoche, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(9, 9, 9)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSeleccionar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        if(Validar()){
            try {
                              
                
                String descripcion = txtDescripcion.getText();                
                java.sql.Date fechaN = new java.sql.Date(dtpFechaNoche.getDate().getTime());
                Double precioXnoche = Double.parseDouble(txtPrecioXNoche.getText());
                
                
                g.agregarNoche(new Noche(fechaN, descripcion, precioXnoche));
                JOptionPane.showMessageDialog(this, "Noche Cargada Correctamente");
                ActualizarLista();
                Limpiar();
                Desactivar();
                listaId = g.obtenerIdNoches();
            } catch (SQLException ex) {
                Logger.getLogger(abmArtistas.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        if(Validar()){
            try {
                
                listaId = g.obtenerIdNoches();
                int id_noc = listaId.get(lstNoches.getSelectedIndex());
                Noche n = new Noche();                
            
                n = g.MostrarNoche(id_noc);
                int id_noche = n.getId_noche();
                String descripcion = n.getDescripcion();
                java.sql.Date fecha = (java.sql.Date)n.getFecha();
                Double precioXnoche = n.getPrecioXnoche();            
                
                
                g.modificarNoche(new Noche(id_noche, fecha, descripcion, precioXnoche));
                JOptionPane.showMessageDialog(this, "noche Actualizada Correctamente");
//                ActualizarLista();
                Limpiar();
                Desactivar();
            } catch (SQLException ex) {
                Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
            }
           
       }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        ActivarNuevo();
        Limpiar();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        try {
            
            listaId = g.obtenerIdNoches();
            int id_noc = listaId.get(lstNoches.getSelectedIndex());
            
            Noche n = new Noche();
                       
                
            
            n = g.MostrarNoche(id_noc);
            int id_noche = n.getId_noche();
            String descripcion = n.getDescripcion();
            java.sql.Date fecha = (java.sql.Date)n.getFecha();
            Double precioXnoche = n.getPrecioXnoche();
           
            
            
            g.EliminarNoche(new Noche(id_noche, fecha, descripcion, precioXnoche));
            JOptionPane.showMessageDialog(null, "Registro eliminado con éxito");
            ActualizarLista();
            Limpiar();
            Desactivar();        
            

        } catch (SQLException ex) {
            Logger.getLogger(abmIntegrantes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        try {
            Limpiar();
            Desactivar();
            listaId = g.obtenerIdNoches();
        } catch (SQLException ex) {
            Logger.getLogger(abmNoche.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnSeleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSeleccionarActionPerformed
        ActivarModificar();
    }//GEN-LAST:event_btnSeleccionarActionPerformed

    private void lstNochesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lstNochesMouseClicked
        MostrarDatos(lstNoches.getSelectedIndex());
    }//GEN-LAST:event_lstNochesMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new abmNoche().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(abmNoche.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JButton btnSeleccionar;
    private org.jdesktop.swingx.JXDatePicker dtpFechaNoche;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JList<String> lstNoches;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtPrecioXNoche;
    // End of variables declaration//GEN-END:variables


    private void Limpiar() {
        
        txtDescripcion.setText("");
        txtPrecioXNoche.setText("");
//        dtpFechaNoche.setDate(date);
    }
    
    private boolean Validar() {
        
        if(txtDescripcion.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe ingresar un Nombre de Noche");
            return false;
        }
        if(dtpFechaNoche.getDate() == null){
            JOptionPane.showMessageDialog(this, "Debe ingresar una fecha de la Noche");
            return false;
        }
        if(txtPrecioXNoche.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Debe ingresar un Precio por la noche");
            return false;
        }       
            
        return true;
    }
    
    private void ActualizarLista() throws SQLException{
        lstNoche = g.listarNoche();
        
        modelLista.removeAllElements();
        for (Noche noche : lstNoche) {
            
            modelLista.addElement(noche);
            
        }
        lstNoches.setModel(modelLista);
        
    } 
    private void Desactivar(){
        
        txtDescripcion.setEnabled(false);
        dtpFechaNoche.setEnabled(false);
        txtPrecioXNoche.setEnabled(false);        
        btnAgregar.setEnabled(false);
        btnCancelar.setEnabled(false);  
        btnModificar.setEnabled(false);
        btnEliminar.setEnabled(true);
        btnNuevo.setEnabled(true);
    
    }
    
    private void ActivarNuevo(){
        
        txtDescripcion.setEnabled(true);
        dtpFechaNoche.setEnabled(true);
        txtPrecioXNoche.setEnabled(true);
        btnAgregar.setEnabled(true);
        btnCancelar.setEnabled(true);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(false);
        btnNuevo.setEnabled(false);
    
    }
    
     private void ActivarModificar(){
        
        txtDescripcion.setEnabled(true);
        dtpFechaNoche.setEnabled(true);
        txtPrecioXNoche.setEnabled(true);
        btnAgregar.setEnabled(false);
        btnCancelar.setEnabled(true);
        btnEliminar.setEnabled(false);
        btnModificar.setEnabled(true);
        btnNuevo.setEnabled(false);
    
    }
    private void MostrarDatos(int posicion) 
    {
                
        try {    
            listaId = g.obtenerIdNoches();
            int id_noche = listaId.get(posicion);
                       
            for (Noche noche : lstNoche) {
                if(id_noche == noche.getId_noche()){
                    Noche n = new Noche();
                    int id = noche.getId_noche();
                    n = g.MostrarNoche(id);
                           
                    txtDescripcion.setText(n.getDescripcion());
                    dtpFechaNoche.setDate(n.getFecha());                    
                    txtPrecioXNoche.setText(String.valueOf(n.getPrecioXnoche()));
                    
                }                
            }               
            
        } catch (SQLException ex) {
            Logger.getLogger(abmArtistas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
