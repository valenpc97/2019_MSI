
package Model;

import java.util.Date;

public class Noche {
    
    private int id_noche;
    private Date fecha;
    private String descripcion;
    private Double precioXnoche;

    public Noche() {
    }

    public Noche(Date fecha, String descripcion, Double precioXnoche) {
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.precioXnoche = precioXnoche;
    }

    public Noche(int id_noche, Date fecha, String descripcion, Double precioXnoche) {
        this.id_noche = id_noche;
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.precioXnoche = precioXnoche;
    }

    public int getId_noche() {
        return id_noche;
    }

    public void setId_noche(int id_noche) {
        this.id_noche = id_noche;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getPrecioXnoche() {
        return precioXnoche;
    }

    public void setPrecioXnoche(Double precioXnoche) {
        this.precioXnoche = precioXnoche;
    }

    @Override
    public String toString() {
        return descripcion + " - Fecha: " + fecha + " Precio de la Noche: " + precioXnoche;
    }
    
    public String toStringCombo() {
        return descripcion + " - Fecha: " + fecha + " Precio de la Noche: " + precioXnoche;
    }
    

   
    
    
    
    
    
    
    
}
