
package Model;


public class Usuario {
    
    private int id_login;
    private String usuario;
    private String contrasenia;
    private int id_tipoLogin;

    public Usuario() {
    }

    public Usuario(int id_login, String usuario, String contrasenia, int id_tipoLogin) {
        this.id_login = id_login;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.id_tipoLogin = id_tipoLogin;
    }

    public Usuario(String usuario, String contraseña, int id_tipoLogin) {
        this.usuario = usuario;
        this.contrasenia = contraseña;
        this.id_tipoLogin = id_tipoLogin;
    }

    public int getId_login() {
        return id_login;
    }

    public void setId_login(int id_login) {
        this.id_login = id_login;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public int getId_tipoLogin() {
        return id_tipoLogin;
    }

    public void setId_tipoLogin(int id_tipoLogin) {
        this.id_tipoLogin = id_tipoLogin;
    }

    @Override
    public String toString() {
        return "Login{" + "id_login=" + id_login + ", usuario=" + usuario + ", contrasenia=" + contrasenia + ", id_tipoLogin=" + id_tipoLogin + '}';
    }
    
    
    
}
