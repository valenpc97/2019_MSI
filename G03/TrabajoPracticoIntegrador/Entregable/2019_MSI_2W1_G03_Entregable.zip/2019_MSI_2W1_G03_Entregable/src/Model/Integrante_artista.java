
package Model;


public class Integrante_artista {
    
    private int id_integrante;
    private String nombre;
    private String apellido;	
    private String tipoDni;
    private int dni;
    private String direccion;
    private String tipoIntegrante;
    private String artista;

    public Integrante_artista() {
    }

    public Integrante_artista(String nombre, String apellido, String tipoDni, int dni, String direccion, String tipoIntegrante, String artista) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.tipoDni = tipoDni;
        this.dni = dni;
        this.direccion = direccion;
        this.tipoIntegrante = tipoIntegrante;
        this.artista = artista;
    }

    public Integrante_artista(int id_integrante, String nombre, String apellido, String tipoDni, int dni, String direccion, String tipoIntegrante, String artista) {
        this.id_integrante = id_integrante;
        this.nombre = nombre;
        this.apellido = apellido;
        this.tipoDni = tipoDni;
        this.dni = dni;
        this.direccion = direccion;
        this.tipoIntegrante = tipoIntegrante;
        this.artista = artista;
    }

    public int getId_integrante() {
        return id_integrante;
    }

    public void setId_integrante(int id_integrante) {
        this.id_integrante = id_integrante;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTipoDni() {
        return tipoDni;
    }

    public void setTipoDni(String tipoDni) {
        this.tipoDni = tipoDni;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTipoIntegrante() {
        return tipoIntegrante;
    }

    public void setTipoIntegrante(String tipoIntegrante) {
        this.tipoIntegrante = tipoIntegrante;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    @Override
    public String toString() {
        return  apellido + ", " + nombre + " - " + tipoIntegrante + " - Miembro de: " + artista;
    }
    
    
    
    
    
    
}
