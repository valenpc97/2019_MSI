
package Model;

public class TipoLogin {
    
    private int id_tipoLogin;
    private String tipoLogin;

    public TipoLogin(int id_tipoLogin, String tipoLogin) {
        this.id_tipoLogin = id_tipoLogin;
        this.tipoLogin = tipoLogin;
    }

    public TipoLogin() {
    }

    public TipoLogin(String tipoLogin) {
        this.tipoLogin = tipoLogin;
    }

    public int getId_tipoLogin() {
        return id_tipoLogin;
    }

    public void setId_tipoLogin(int id_tipoLogin) {
        this.id_tipoLogin = id_tipoLogin;
    }

    public String getTipoLogin() {
        return tipoLogin;
    }

    public void setTipoLogin(String tipoLogin) {
        this.tipoLogin = tipoLogin;
    }

    @Override
    public String toString() {
        return  tipoLogin ;
    }
    
    
    
}
