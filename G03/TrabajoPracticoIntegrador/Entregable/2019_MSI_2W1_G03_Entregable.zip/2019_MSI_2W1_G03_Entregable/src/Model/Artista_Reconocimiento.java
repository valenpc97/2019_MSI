
package Model;

import java.sql.Date;


public class Artista_Reconocimiento {
    
    private int id_artista;
    private String artista;
    private Date fechaInicioDisponibilidad;
    private Date fechaFinDisponibilidad;
    private String reconocimiento;
    private String historia;

    public Artista_Reconocimiento() {
    }

    public Artista_Reconocimiento(String artista, Date fechaInicioDisponibilidad, Date fechaFinDisponibilidad, String reconocimiento, String historia) {
        this.artista = artista;
        this.fechaInicioDisponibilidad = fechaInicioDisponibilidad;
        this.fechaFinDisponibilidad = fechaFinDisponibilidad;
        this.reconocimiento = reconocimiento;
        this.historia = historia;
    }

    public Artista_Reconocimiento(int id_artista, String artista, Date fechaInicioDisponibilidad, Date fechaFinDisponibilidad, String reconocimiento, String historia) {
        this.id_artista = id_artista;
        this.artista = artista;
        this.fechaInicioDisponibilidad = fechaInicioDisponibilidad;
        this.fechaFinDisponibilidad = fechaFinDisponibilidad;
        this.reconocimiento = reconocimiento;
        this.historia = historia;
    }

    public int getId_artista() {
        return id_artista;
    }

    public void setId_artista(int id_artista) {
        this.id_artista = id_artista;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public Date getFechaInicioDisponibilidad() {
        return fechaInicioDisponibilidad;
    }

    public void setFechaInicioDisponibilidad(Date fechaInicioDisponibilidad) {
        this.fechaInicioDisponibilidad = fechaInicioDisponibilidad;
    }

    public Date getFechaFinDisponibilidad() {
        return fechaFinDisponibilidad;
    }

    public void setFechaFinDisponibilidad(Date fechaFinDisponibilidad) {
        this.fechaFinDisponibilidad = fechaFinDisponibilidad;
    }

    public String getReconocimiento() {
        return reconocimiento;
    }

    public void setReconocimiento(String reconocimiento) {
        this.reconocimiento = reconocimiento;
    }

    public String getHistoria() {
        return historia;
    }

    public void setHistoria(String historia) {
        this.historia = historia;
    }

    @Override
    public String toString() {
        return artista  + "Disponible Desde: " + fechaInicioDisponibilidad + " - Hasta" + fechaFinDisponibilidad + " - Reconocimiento:" + reconocimiento;
    }
    
    
    
}
