/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

public class TipoIntegrante {
    
    private int id_tipoIntegrante;
    private String tipoIntegrante;

    public TipoIntegrante(int id_tipoIntegrante, String tipoIntegrante) {
        this.id_tipoIntegrante = id_tipoIntegrante;
        this.tipoIntegrante = tipoIntegrante;
    }

    public TipoIntegrante() {
    }

    public TipoIntegrante(String tipoIntegrante) {
        this.tipoIntegrante = tipoIntegrante;
    }

    public int getId_tipoIntegrante() {
        return id_tipoIntegrante;
    }

    public void setId_tipointegrante(int id_tipointegrante) {
        this.id_tipoIntegrante = id_tipointegrante;
    }

    public String getTipoIntegrante() {
        return tipoIntegrante;
    }

    public void setTipoIntegrante(String tipoIntegrante) {
        this.tipoIntegrante = tipoIntegrante;
    }

    @Override
    public String toString() {
        return tipoIntegrante;
    }
    
    

    
    
}
