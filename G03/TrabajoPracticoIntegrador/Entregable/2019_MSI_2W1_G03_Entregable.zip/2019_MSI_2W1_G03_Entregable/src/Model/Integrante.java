/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;


public class Integrante {

    private int id_integrante;
    private String nombre;
    private String apellido;	
    private int id_tipoDni;
    private int dni;
    private String direccion;
    private int	id_tipoIntegrante;
    private int id_artista;

    public Integrante() {
    }

    public Integrante(String nombre, String apellido, int id_tipoDni, int dni, String direccion, int id_tipoIntegrante, int id_artista) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.id_tipoDni = id_tipoDni;
        this.dni = dni;
        this.direccion = direccion;
        this.id_tipoIntegrante = id_tipoIntegrante;
        this.id_artista = id_artista;
    }

    public Integrante(int id_integrante, String nombre, String apellido, int id_tipoDni, int dni, String direccion, int id_tipoIntegrante, int id_artista) {
        this.id_integrante = id_integrante;
        this.nombre = nombre;
        this.apellido = apellido;
        this.id_tipoDni = id_tipoDni;
        this.dni = dni;
        this.direccion = direccion;
        this.id_tipoIntegrante = id_tipoIntegrante;
        this.id_artista = id_artista;
    }

    public int getId_integrante() {
        return id_integrante;
    }

    public void setId_integrante(int id_integrante) {
        this.id_integrante = id_integrante;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getId_tipoDni() {
        return id_tipoDni;
    }

    public void setId_tipoDni(int id_tipoDni) {
        this.id_tipoDni = id_tipoDni;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getId_tipoIntegrante() {
        return id_tipoIntegrante;
    }

    public void setId_tipoIntegrante(int id_tipoIntegrante) {
        this.id_tipoIntegrante = id_tipoIntegrante;
    }

    public int getId_artista() {
        return id_artista;
    }

    public void setId_artista(int id_artista) {
        this.id_artista = id_artista;
    }

    

    @Override
    public String toString() {
        return "Nombre=" + apellido + ", " + nombre +" Tipo de Integrante" + id_tipoIntegrante;
    }
    
    

    
    
    
    
}
