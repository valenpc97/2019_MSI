
package Model;


public class Reconocimiento {
    
    private int id_reconocimiento;
    private String reconocimiento;

    public Reconocimiento() {
    }

    public Reconocimiento(int id_reconocimiento, String reconocimiento) {
        this.id_reconocimiento = id_reconocimiento;
        this.reconocimiento = reconocimiento;
    }

    public Reconocimiento(String reconocimiento) {
        this.reconocimiento = reconocimiento;
    }

    public int getId_reconocimiento() {
        return id_reconocimiento;
    }

    public void setId_reconocimiento(int id_reconocimiento) {
        this.id_reconocimiento = id_reconocimiento;
    }

    public String getReconocimiento() {
        return reconocimiento;
    }

    public void setReconocimiento(String reconocimiento) {
        this.reconocimiento = reconocimiento;
    }

    @Override
    public String toString() {
        return  reconocimiento;
    }
    
    

    
}