
package Model;


public class Presentacion_noche {
    
    private int id_presentacion;
    private String artista;
    private String horarioComienzo;
    private String noche;

    public Presentacion_noche() {
    }

    public Presentacion_noche(String artista, String horarioComienzo, String noche) {
        this.artista = artista;
        this.horarioComienzo = horarioComienzo;
        this.noche = noche;
    }

    public Presentacion_noche(int id_presentacion, String artista, String horarioComienzo, String noche) {
        this.id_presentacion = id_presentacion;
        this.artista = artista;
        this.horarioComienzo = horarioComienzo;
        this.noche = noche;
    }

    public int getId_presentacion() {
        return id_presentacion;
    }

    public void setId_presentacion(int id_presentacion) {
        this.id_presentacion = id_presentacion;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public String getHorarioComienzo() {
        return horarioComienzo;
    }

    public void setHorarioComienzo(String horarioComienzo) {
        this.horarioComienzo = horarioComienzo;
    }

    public String getNoche() {
        return noche;
    }

    public void setNoche(String noche) {
        this.noche = noche;
    }

    @Override
    public String toString() {
        return "Presentacion_noche{" + "id_presentacion=" + id_presentacion + ", artista=" + artista + ", horarioComienzo=" + horarioComienzo + ", noche=" + noche + '}';
    }
    
    
    
}
