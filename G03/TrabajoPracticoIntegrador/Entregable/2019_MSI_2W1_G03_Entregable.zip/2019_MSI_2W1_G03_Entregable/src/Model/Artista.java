
package Model;

import java.sql.Date;

public class Artista {

    private int id_artista;
    private String artista;
    private Date fechaInicioDisponibilidad;
    private Date fechaFinDisponibilidad;
    private int id_reconocimiento;
    private String historia;

    public Artista(int id_artista, String artista, Date fechaInicioDisponibilidad, Date fechaFinDisponibilidad, int id_reconocimiento, String historia) {
        this.id_artista = id_artista;
        this.artista = artista;
        this.fechaInicioDisponibilidad = fechaInicioDisponibilidad;
        this.fechaFinDisponibilidad = fechaFinDisponibilidad;
        this.id_reconocimiento = id_reconocimiento;
        this.historia = historia;
    }

    public Artista(String artista, Date fechaInicioDisponibilidad, Date fechaFinDisponibilidad, int id_reconocimiento, String historia) {
        this.artista = artista;
        this.fechaInicioDisponibilidad = fechaInicioDisponibilidad;
        this.fechaFinDisponibilidad = fechaFinDisponibilidad;
        this.id_reconocimiento = id_reconocimiento;
        this.historia = historia;
    }

    public Artista() {
    }

    public int getId_artista() {
        return id_artista;
    }

    public void setId_artista(int id_artista) {
        this.id_artista = id_artista;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public Date getFechaInicioDisponibilidad() {
        return fechaInicioDisponibilidad;
    }

    public void setFechaInicioDisponibilidad(Date fechaInicioDisponibilidad) {
        this.fechaInicioDisponibilidad = fechaInicioDisponibilidad;
    }

    public Date getFechaFinDisponibilidad() {
        return fechaFinDisponibilidad;
    }

    public void setFechaFinDisponibilidad(Date fechaFinDisponibilidad) {
        this.fechaFinDisponibilidad = fechaFinDisponibilidad;
    }

    public int getId_reconocimiento() {
        return id_reconocimiento;
    }

    public void setId_reconocimiento(int id_reconocimiento) {
        this.id_reconocimiento = id_reconocimiento;
    }

    public String getHistoria() {
        return historia;
    }

    public void setHistoria(String historia) {
        this.historia = historia;
    }

    
   
    

    @Override
    public String toString() {
        return  artista;
    }
    
    
    

}