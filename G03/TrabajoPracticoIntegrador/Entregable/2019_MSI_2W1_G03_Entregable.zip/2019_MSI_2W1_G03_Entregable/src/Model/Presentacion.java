
package Model;

import java.sql.Time;

public class Presentacion {
    
    private int id_presentacion;
    private int id_artista;
    private String horarioComienzo;
    private int id_noche;

    public Presentacion() {
    }

    public Presentacion(int id_presentacion, int id_artista, String horarioComienzo, int id_noche) {
        this.id_presentacion = id_presentacion;
        this.id_artista = id_artista;
        this.horarioComienzo = horarioComienzo;
        this.id_noche = id_noche;
    }

    public Presentacion(int id_artista, String horarioComienzo, int id_noche) {
        this.id_artista = id_artista;
        this.horarioComienzo = horarioComienzo;
        this.id_noche = id_noche;
    }

    public int getId_presentacion() {
        return id_presentacion;
    }

    public void setId_presentacion(int id_presentacion) {
        this.id_presentacion = id_presentacion;
    }

    public int getId_artista() {
        return id_artista;
    }

    public void setId_artista(int id_artista) {
        this.id_artista = id_artista;
    }

    public String getHorarioComienzo() {
        return horarioComienzo;
    }

    public void setHorarioComienzo(String horarioComienzo) {
        this.horarioComienzo = horarioComienzo;
    }

    public int getId_noche() {
        return id_noche;
    }

    public void setId_noche(int id_noche) {
        this.id_noche = id_noche;
    }

    
    @Override
    public String toString() {
        return "Presentacion{" + "id_presentacion=" + id_presentacion + ", id_artista=" + id_artista + ", horarioComienzo=" + horarioComienzo + '}';
    }
    
    
    
}
