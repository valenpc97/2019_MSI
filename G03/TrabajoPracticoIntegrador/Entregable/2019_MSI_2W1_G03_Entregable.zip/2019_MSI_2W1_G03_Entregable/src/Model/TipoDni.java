
package Model;


public class TipoDni {
    
    private int id_tipoDni;
    private String tipoDni;

    public TipoDni() {
    }

    public TipoDni(int id_tipoDni, String tipoDni) {
        this.id_tipoDni = id_tipoDni;
        this.tipoDni = tipoDni;
    }

    public int getId_tipoDni() {
        return id_tipoDni;
    }

    public void setId_tipoDni(int id_tipoDni) {
        this.id_tipoDni = id_tipoDni;
    }

    public String getTipoDni() {
        return tipoDni;
    }

    public void setTipoDni(String tipoDni) {
        this.tipoDni = tipoDni;
    }

    @Override
    public String toString() {
        return tipoDni;
    }
    
    
    
}
