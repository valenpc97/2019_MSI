package Controlador;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import vistas.Inicio.Principal;

public class Festival {

    public static void main(String[] args) {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Festival.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Principal p = new Principal();
        p.setVisible(true);
        
    }
    
    /*public void IconoFrame(){
        setIconImage(new ImageIcon(getClass().getResource("")));
    }*/  
    
}
