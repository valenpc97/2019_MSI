package Controlador;

import Model.Artista;
import Model.Artista_Reconocimiento;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import Model.Integrante;
import Model.Integrante_artista;
import Model.Usuario;
import Model.Noche;
import Model.Presentacion;
import Model.Presentacion_noche;
import Model.Reconocimiento;
import Model.TipoDni;
import Model.TipoIntegrante;
import Model.TipoLogin;
import java.util.Map;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author LEGUERO
 */
public class Gestor {

    private static final String USER = "sa";
    private static final String PASS = "123456";
    private static final String CONN = "jdbc:sqlserver://Emma-PC\\"
            + "SQLEXPRESS:1433;databaseName=tp_metodologia_festival2";
    
    
    //----------------------------METODOS DE ARTISTAS---------------------------
    //METODO LISTAR RECONOCIMIENTO
    public ArrayList<Reconocimiento> listarReconocimiento() throws SQLException
    {
        ArrayList<Reconocimiento> reconocimientos = new ArrayList<>();
        Connection con = DriverManager.getConnection(CONN, USER, PASS );
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("select * from Reconocimiento");
        while (rs.next()) {
            int id_reconocimiento = rs.getInt(1);
            String reconocimiento = rs.getString(2);
            
            Reconocimiento r = new Reconocimiento(id_reconocimiento, 
                    reconocimiento);
            reconocimientos.add(r);
        }
        
        rs.close();
        st.close();
        con.close();

        return reconocimientos;
    }
    
    public void agregarArtista(Artista nuevo) throws SQLException {
        
            Connection con = DriverManager.getConnection(CONN, USER, PASS);
            PreparedStatement pst = con.prepareStatement("insert into Artista(artista, fechaInicioDisponibilidad, fechaFinDisponibilidad, id_reconocimiento, historia) values(? , ? , ? , ? , ? )");
            pst.setString(1, nuevo.getArtista());            
            pst.setDate(2, (java.sql.Date) nuevo.getFechaInicioDisponibilidad());
            pst.setDate(3, (java.sql.Date) nuevo.getFechaFinDisponibilidad());
            pst.setInt(4, nuevo.getId_reconocimiento());
            pst.setString(5, nuevo.getHistoria());
            
            pst.execute();
            
            pst.close();        
            con.close();
         

    }
    
    public ArrayList<Artista> ComboArtista() 
            throws SQLException {
        {
            ArrayList<Artista> artistas = new 
        ArrayList<>();
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection con = DriverManager.getConnection(CONN, USER, PASS);
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("select *\n" +
                                               "from Artista");

                while (rs.next()) {
                    int id_artista = rs.getInt(1);
                    String artista = rs.getString(2);
                    Date fechaInicioDisponibilidad = (java.sql.Date)rs.getDate(3);
                    Date fechaFinDisponibilidad = (java.sql.Date)rs.getDate(4);
                    int reconocimiento = rs.getInt(5);
                    String historia = rs.getString(6);
                       

                    Artista a = new Artista(id_artista, artista, (java.sql.Date)fechaInicioDisponibilidad, (java.sql.Date)fechaFinDisponibilidad, reconocimiento, historia);
                    artistas.add(a);

                }
                
                rs.close();
                st.close();
                con.close();

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null,
                        ex);
            }

            return artistas;
        }

    }
    
    public ArrayList<Artista_Reconocimiento> listarArtista() 
            throws SQLException {
        {
            ArrayList<Artista_Reconocimiento> artistas = new 
        ArrayList<>();
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection con = DriverManager.getConnection(CONN, USER, PASS);
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("select id_artista,"
                                             + "artista, "
                                             + "fechaInicioDisponibilidad, "
                                             + "fechaFinDisponibilidad , "
                                             + "r.reconocimiento, "
                                             + "historia "
                                             + "from artista a join "
+ "Reconocimiento r on r.id_reconocimiento  = a.id_reconocimiento");

                while (rs.next()) {
                    int id_artista = rs.getInt(1);
                    String artista = rs.getString(2);
                    Date fechaInicioDisponibilidad = (java.sql.Date)rs.getDate(3);
                    Date fechaFinDisponibilidad = (java.sql.Date)rs.getDate(4);
                    String reconocimiento = rs.getString(5);
                    String historia = rs.getString(6);
                       

                    Artista_Reconocimiento a = new Artista_Reconocimiento(id_artista,artista,(java.sql.Date)fechaInicioDisponibilidad, (java.sql.Date)fechaFinDisponibilidad,reconocimiento, historia);
                    artistas.add(a);

                }
                
                rs.close();
                st.close();
                con.close();

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null,
                        ex);
            }

            return artistas;
        }

    }
    
    
    public ArrayList<Integer> obtenerIdArtistas() throws SQLException{
        
            ArrayList<Integer>lista = new ArrayList<>();
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection con = DriverManager.getConnection(CONN, USER, PASS);
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("select id_artista "
                                             + "from artista");
              
                while (rs.next()) {
                    int id_artista = rs.getInt(1);
                   
                    lista.add(id_artista);
                }
                
                rs.close();
                st.close();
                con.close();

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null,
                        ex);
            }

            return lista;
        
    }
    public Artista MostrarArtista(int id_artista) throws SQLException {
        
        Artista a = null;
        Connection con = DriverManager.getConnection(CONN,USER, PASS);
        PreparedStatement pst = con.prepareStatement("select * " +
                                                     "from Artista " +
                                                     "where id_artista = ?");
            
            pst.setInt(1, id_artista);
            ResultSet rs = pst.executeQuery();
            if(rs.next())
            {
                String artista = rs.getString(2);
                Date fechaInicio = (java.sql.Date)rs.getDate(3);
                Date fechaFin = (java.sql.Date)rs.getDate(4);
                int id_reconocimiento = rs.getInt(5);
                String historia = rs.getString(6);
                
                
                a = new Artista(id_artista, artista, (java.sql.Date) fechaInicio, (java.sql.Date) fechaFin, id_reconocimiento, historia);
            }
            rs.close();
            pst.close();
            con.close();

            return a;
    }
    
    public boolean modificarArtista(Artista a) throws SQLException{
        
        Connection con = DriverManager.getConnection(CONN, USER, PASS);
        PreparedStatement st = con.prepareStatement("update Artista\n" +
                                                         "set artista = ?,\n" +                                                         
                                                         "    fechaInicioDisponibilidad = ?,\n" +
                                                         "    fechaFinDisponibilidad = ?,\n" +
                                                         "    id_reconocimiento = ?,\n" +
                                                         "    historia = ?\n" +
                                                         "where id_artista = ?");
        
        st.setString(1, a.getArtista());        
        st.setDate(2,(java.sql.Date) a.getFechaInicioDisponibilidad());
        st.setDate(3,(java.sql.Date) a.getFechaFinDisponibilidad());
        st.setInt(4, a.getId_reconocimiento());
        st.setString(5, a.getHistoria());
        st.setInt(6, a.getId_artista());
        
        int filas = st.executeUpdate();
        
        st.close();
        con.close();
        
        if(filas > 0)
            return true;
        else
            return false; 
                       
    }
    
    public boolean EliminarArtista(Artista a ) throws SQLException {

        Connection con = DriverManager.getConnection(CONN, USER, PASS);
        PreparedStatement st = con.prepareStatement("DELETE FROM Artista "
                + "WHERE id_artista = ?");
        st.setInt(1, a.getId_artista());
        int filas = st.executeUpdate();
        
        st.close();
        con.close();
        
        if(filas > 0)
            return true;
        else
            return false; 
    }
    
    //----------------------------METODOS DE INTEGRANTES------------------------
    //METODO LISTAR TIPO DNI    
    public ArrayList<TipoDni> listarTipoDni(){
        ArrayList<TipoDni> lista = new ArrayList<>();
        try {
            
            Connection con = DriverManager.getConnection(CONN, USER, PASS );
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from TipoDni");
            while (rs.next()) {
                int id_tipoDni = rs.getInt(1);
                String tipoDni = rs.getString(2);
                
                TipoDni t = new TipoDni(id_tipoDni, tipoDni);
                lista.add(t);
            }
            rs.close();
            st.close();
            con.close();
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, 
                    ex);
        }
        return lista;

    }
    
    //LISTAR TODOS LOS INTEGRANTES
    public ArrayList<Integrante_artista> listarIntegrantes() {
        ArrayList<Integrante_artista> integrantes = new 
        ArrayList<>();
        try {
                
                Connection con = DriverManager.getConnection(CONN,USER, PASS);
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT id_integrante,\n" +
                                               "       nombre,\n" +
                                               "       apellido,\n" +
                                               "       tdni.tipoDni,\n" +
                                               "       dni,\n" +
                                               "       direccion,\n" +
                                               "       ti.tipoIntegrante,\n" +
                                               "       a.artista\n" +
                                               "FROM Integrante i join TipoDni tdni on i.id_tipoDni = tdni.id_tipoDni\n" +
                                               "     join TipoIntegrante ti on i.id_tipoIntegrante = ti.id_tipoIntegrante\n" +
                                               "     join Artista a on i.id_integrante = a.id_artista");
                while (rs.next()) {
                    
                    int id_integrante = rs.getInt(1);
                    String nombre = rs.getString(2);
                    String apellido = rs.getString(3);
                    String tipoDni =rs.getString(4);
                    int dni = rs.getInt(5);
                    String direccion = rs.getString(6);
                    String tipoIntegrante = rs.getString(7);
                    String artista = rs.getString(8);
                    
                    Integrante_artista inte = new Integrante_artista(id_integrante, nombre, apellido, tipoDni, dni, direccion, tipoIntegrante, artista);
                    integrantes.add(inte);
                    
                }
                rs.close();
                st.close();
                con.close();
                
                
            } catch (SQLException ex) {
                Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null
                        , ex);
            }
        return integrantes;
    }
    
        
    //METODO MOSTRAR INTEGRANTE - SIRVE PARA MOSTRAR UN SOLO INTEGRANTE
    public Integrante MostrarIntegrante(int id_integrante) throws SQLException {
        
    
            Integrante i = null;
            Connection con = DriverManager.getConnection(CONN,USER, PASS);
            PreparedStatement pst = con.prepareStatement("SELECT id_integrante,\n" +
"	   nombre,\n" +
"	   apellido,\n" +
"	   id_tipoDni,\n" +
"	   dni,\n" +
"	   direccion,\n" +
"	   id_tipoIntegrante,\n" +
"	   id_artista\n" +
"FROM Integrante \n" +
"WHERE id_integrante = ?");
            
            pst.setInt(1, id_integrante);
            ResultSet rs = pst.executeQuery();
            if(rs.next())
            {
                String nombre = rs.getString(2);
                String apellido = rs.getString(3);
                int id_tipoDni = rs.getInt(4);
                int dni = rs.getInt(5);
                String direccion = rs.getString(6);
                int id_tipoIntegrante = rs.getInt(7);
                int id_artista = rs.getInt(8);
                
                i = new Integrante(id_integrante, nombre, apellido, id_tipoDni, dni, direccion, id_tipoIntegrante, id_artista);
            }
            rs.close();
            pst.close();
            con.close();

            return i;
        
    }
    
    // METODO AGREGAR INTEGRANTE
    public void agregarIntegrante(Integrante nuevo){
        
        try {
            Connection con = DriverManager.getConnection(CONN, USER, PASS);
            PreparedStatement pst = con.prepareStatement("insert into Integrante(nombre,apellido,id_tipoDni,dni,direccion,id_tipoIntegrante,id_artista) values(? , ? , ? , ? , ? , ?, ? )");
            pst.setString(1, nuevo.getNombre());
            pst.setString(2, nuevo.getApellido());
            pst.setInt(3, nuevo.getId_tipoDni());
            pst.setInt(4, nuevo.getDni());
            pst.setString(5, nuevo.getDireccion());
            pst.setInt(6, nuevo.getId_tipoIntegrante());
            pst.setInt(7, nuevo.getId_artista());
            
            pst.execute();
            
            pst.close();        
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, 
                    ex);
        }

    }
    
    //METODO OBTENER ID INTEGRANTES EN UNA LISTA
    public ArrayList<Integer> obtenerIdIntegrantes() throws SQLException{
        
        ArrayList<Integer>lista = new ArrayList<>();
        try {
            
            
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(CONN, USER, PASS);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select id_integrante "
                    + "from Integrante");
            
            while (rs.next()) {
                int id_integrante = rs.getInt(1);
                
                lista.add(id_integrante);
            }
            
            rs.close();
            st.close();
            con.close();
            
            
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
        
        
    }
    
    //METODO MODIFICAR INTEGRANTE
    public boolean modificarIntegrante(Integrante i) throws SQLException{
        
        Connection con = DriverManager.getConnection(CONN, USER, PASS);
        PreparedStatement st = con.prepareStatement("UPDATE Integrante\n" +
                                                    "SET nombre = ?,\n" +
                                                    "	apellido = ?,\n" +
                                                    "	id_tipoDni = ?,\n" +
                                                    "	dni = ?,\n" +
                                                    "	direccion = ?,\n" +
                                                    "	id_tipoIntegrante = ?,\n" +
                                                    "	id_artista = ?\n" +
                                                    "WHERE id_integrante = ?");
        st.setString(1, i.getNombre());
        st.setString(2, i.getApellido());
        st.setInt(3, i.getId_tipoDni());
        st.setInt(4, i.getDni());
        st.setString(5, i.getDireccion());
        st.setInt(6, i.getId_tipoIntegrante());
        st.setInt(7,i.getId_artista());
        st.setInt(8,i.getId_integrante());
        
         int filasAfectadas = st.executeUpdate();
        
        st.close();
        con.close();
        
        if (filasAfectadas > 0) {
            return true;
        } else {
            return false;
        }        
    }
    
    //METODO ELIMINAR INTEGRANTE
    public boolean eliminarIntegrante(Integrante i ) throws SQLException {

        Connection con = DriverManager.getConnection(CONN, USER, PASS);
        PreparedStatement st = con.prepareStatement("DELETE FROM Integrante "
                + "WHERE id_integrante = ?");
        st.setInt(1, i.getId_integrante());
        int filas = st.executeUpdate();
        
        st.close();
        con.close();
        
        if(filas > 0)
            return true;
        else
            return false; 
    }

    
     
    //----------------------------METODOS DE NOCHES-----------------------------
    public ArrayList<Noche> listarNoche() throws SQLException {
        {
            ArrayList<Noche> noches = new ArrayList<>();
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection con = DriverManager.getConnection(CONN, USER, PASS);
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("select fecha, descripcion, "
                        + " precioXnoche from "
                        + "Noche ");

                while (rs.next()) {
                    Date fecha = (java.sql.Date)rs.getDate(1);
                    String descripcion = rs.getString(2);
                    double precioXnoche = rs.getDouble(3);
                    
                    Noche n = new Noche(fecha, descripcion, precioXnoche);
                    noches.add(n);

                }
                con.close();
                rs.close();
                st.close();

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null,
                        ex);
            }

            return noches;
        }

    }
    
    public ArrayList<Integer> obtenerIdNoches() throws SQLException{
        
            ArrayList<Integer>lista = new ArrayList<>();
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection con = DriverManager.getConnection(CONN, USER, PASS);
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("select id_noche "
                                             + "from Noche");
              
                while (rs.next()) {
                    int id_artista = rs.getInt(1);
                   
                    lista.add(id_artista);
                }
                
                rs.close();
                st.close();
                con.close();

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null,
                        ex);
            }

            return lista;
        
    }
    
    public Noche MostrarNoche(int id_noche) throws SQLException {
        
        Noche n = null;
        Connection con = DriverManager.getConnection(CONN,USER, PASS);
        PreparedStatement pst = con.prepareStatement("select * " +
                                                     "from Noche " +
                                                     "where id_noche = ?");
            
            pst.setInt(1, id_noche);
            ResultSet rs = pst.executeQuery();
            if(rs.next())
            {
                Date fecha = (java.sql.Date)rs.getDate(2);
                String descripcion = rs.getString(3);                
                Double precioXnoche = Double.valueOf(rs.getFloat(4));
                
                
                n = new Noche(id_noche, fecha, descripcion, precioXnoche);
            }
            rs.close();
            pst.close();
            con.close();

            return n;
    }
    
    public void agregarNoche(Noche nuevo) throws SQLException {
        
            Connection con = DriverManager.getConnection(CONN, USER, PASS);
            PreparedStatement pst = con.prepareStatement("INSERT INTO Noche (fecha , descripcion , precioXnoche) VALUES( ? , ? , ? )");
            
            pst.setDate(1, (java.sql.Date) nuevo.getFecha());
            pst.setString(2, nuevo.getDescripcion());                        
            pst.setFloat(3, nuevo.getPrecioXnoche().floatValue());
                        
            pst.execute();
            
            pst.close();        
            con.close();
         

    }
    
    public boolean modificarNoche(Noche n) throws SQLException{
        
        Connection con = DriverManager.getConnection(CONN, USER, PASS);
        PreparedStatement st = con.prepareStatement("update Noche\n" +
                                                    "set fecha = ?,\n" +
                                                    "descripcion = ?,\n" +
                                                    "precioXnoche = ?\n" +
                                                    "where id_noche = ? ");
        
        st.setDate(1,(java.sql.Date) n.getFecha());        
        st.setString(2, n.getDescripcion());       
        st.setFloat(3, n.getPrecioXnoche().floatValue());    
        st.setInt(4, n.getId_noche());
        
        int filas = st.executeUpdate();
        
        st.close();
        con.close();
        
        if(filas > 0)
            return true;
        else
            return false; 
                       
    }
    
    
     public boolean EliminarNoche(Noche n ) throws SQLException {

        Connection con = DriverManager.getConnection(CONN, USER, PASS);
        PreparedStatement st = con.prepareStatement("DELETE FROM Noche "
                + "WHERE id_noche = ?");
        st.setInt(1, n.getId_noche());
        int filas = st.executeUpdate();
        
        st.close();
        con.close();
        
        if(filas > 0)
            return true;
        else
            return false; 
    }
    
    //----------------------------METODOS DE PRESENTACION-----------------------


    public int EliminarPresentacionesPorId(int id ) throws SQLException {

        Connection con = DriverManager.getConnection(CONN, USER, PASS);
        PreparedStatement st = con.prepareStatement("DELETE FROM Presentacion "
                + "WHERE id_presentacion = ?");
        st.setInt(1, id);
        int filas = st.executeUpdate();
        
        st.close();
        con.close();
        
        if(filas > 0)
            return 1;
        else
            return 0; 
    }

    public void agregarPresentacion (Presentacion nuevo) throws SQLException
     {
         try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(CONN, USER, PASS );
            PreparedStatement pst = con.prepareStatement("insert into "
                    + "Presentacion values (? , ? , ? )");
            pst.setInt(1, nuevo.getId_artista());
            pst.setString(2, nuevo.getHorarioComienzo());   
            pst.setInt(3, nuevo.getId_noche());
            
            
            pst.execute();
            pst.close();
            con.close();
            

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, 
                    ex);
        }
     }


































//    public ArrayList<Presentacion_Artista> listarPresentacion() 
//            throws SQLException {
//        {
//            ArrayList<Presentacion_Artista> presentaciones = new ArrayList<>();
//            try {
//                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//                Connection con = DriverManager.getConnection(USER, PASS, CONN);
//                Statement st = con.createStatement();
//                ResultSet rs = st.executeQuery("select a.artista, "
//                        + "horarioComienzo from Presentacion p join Artista a "
//                        + "on p.id_artista = a.id_artista");
//
//                while (rs.next()) {
//                    
//                    String artista = rs.getString(1);
//                    String horario = rs.getString(2);
//                    
//                    
//                    Presentacion_Artista pvm = new Presentacion_Artista( artista
//                            , horario);
//                    presentaciones.add(pvm);
//
//                }
//                con.close();
//                rs.close();
//                st.close();
//
//            } catch (ClassNotFoundException ex) {
//                Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null,
//                        ex);
//            }
//
//            return presentaciones;
//        }
//
//    }
//   
     
     
     
    
    
    
//    
//     
//     
//     
//     public void agregarNoche(Noche nuevo) throws SQLException
//     {
//         try {
//            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            Connection con = DriverManager.getConnection(USER, PASS, CONN);
//            PreparedStatement pst = con.prepareStatement("insert into noche "
//                    + "values (?,?,?,?)");
//            pst.setDate(1, (java.sql.Date) nuevo.getFecha());
//            pst.setString(2, nuevo.getDescripcion());
//            pst.setInt(3, nuevo.getId_presentacion());
//            pst.setDouble(4, nuevo.getPrecioXnoche());
//            
//            pst.execute();
//            
//            pst.close();
//            con.close();
//            
//
//        } catch (ClassNotFoundException ex) {
//            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, 
//                    ex);
//        }
//     }
//     
//     
     
     
     
    //------------------METODOS LOGIN ------------------------------------------
    
    
    public ArrayList<TipoLogin> listarTipoLogin() {
        ArrayList<TipoLogin> perfil = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection(CONN, USER, PASS);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("Select * from TipoLogin");
            while (rs.next()) {
                int id_tipoLogin = rs.getInt(1);
                String tipoLogin = rs.getString(2);

                perfil.add(new TipoLogin(id_tipoLogin, tipoLogin));
            }
            rs.close();
            st.close();
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, 
                    ex);
        }
        return perfil;
    }
    
    public void agregarUsuario(Usuario nuevo) throws SQLException {
        
        Connection con = DriverManager.getConnection(CONN, USER, PASS);
        PreparedStatement pst = con.prepareStatement("insert into Usuario (usuario, contrasenia, id_tipoLogin) values (?, ?, ?)");
            pst.setString(1, nuevo.getUsuario());
            pst.setString(2, nuevo.getContrasenia());
            pst.setInt(3, nuevo.getId_tipoLogin());
            
            pst.executeUpdate();
                        
            pst.close();        
            con.close();
    }
    
    public boolean existeUsuario(String usuario, String contrasenia, int id_tipoLogin) throws SQLException {
        boolean existe = false;
        
            Connection con = DriverManager.getConnection(CONN, USER, PASS);

            String sql = "select * from Usuario WHERE usuario = ? AND contrasenia = ? AND id_tipoLogin = ? ";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, usuario);
            st.setString(2, contrasenia);
            st.setInt(3, id_tipoLogin);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                existe = true;
            }
            rs.close();
            st.close();
            con.close();

        return existe;
    }
    
    

    public ArrayList<Presentacion_noche> ListarPresentacion() {
        ArrayList<Presentacion_noche> presentacion = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection(CONN, USER, PASS );
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select id_presentacion,\n" +
                                           "	   horarioComienzo,\n" +
                                           "	   a.artista,\n" +
                                           "	   n.descripcion\n" +
                                           "from Presentacion p join Noche n on p.id_noche = n.id_noche\n" +
                                           "	 join Artista a on p.id_artista = a.id_artista");

            while (rs.next()) {
                int id_presentacion = rs.getInt(1);
                String horario = rs.getString(2);
                String artista = rs.getString(3);
                String descripcion = rs.getString(4);

                presentacion.add(new Presentacion_noche(id_presentacion , artista, horario, descripcion));
            }

            rs.close();
            st.close();
            conn.close();

        } catch (SQLException ex) {
            Logger.getLogger(Gestor.class.getName()).log(Level.SEVERE, null, 
                    ex);
        }
        return presentacion;
    } 
    
         public ArrayList<Presentacion> ListarPresentacionPorNoche(int id_noche) throws SQLException {
        ArrayList<Presentacion> presentacion = new ArrayList<>();
        
        Connection con = DriverManager.getConnection(CONN, USER, PASS );
            PreparedStatement pst = con.prepareStatement("select id_presentacion,\n" +
                                                        "	   horarioComienzo,\n" +
                                                        "	   a.artista\n" +
                                                        "from Presentacion p join Noche n on p.id_noche = n.id_noche\n" +
                                                        "	 join Artista a on a.id_artista=p.id_artista\n" +
                                                        "where p.id_noche = ?\n" +
                                                        "order by 1");
            
            pst.setInt(1, id_noche);
            ResultSet rs = pst.executeQuery();
            if(rs.next())
            {
                int id_presentacion = rs.getInt(2);               
                String horarioComienzo = rs.getString(3);
                int artista = rs.getInt(4);
                int id = id_noche;
                Presentacion presen = new Presentacion(id_presentacion, artista, horarioComienzo,id);
                    
                presentacion.add(presen);             
            
            }
            rs.close();
            pst.close();
            con.close();
        
        return presentacion;   
    }
         
         
         
        public void  Reporte(Map NullPointerException) throws JRException, SQLException{
            Connection con = DriverManager.getConnection("jdbc:sqlserver://Emma-PC\\SQLEXPRESS:1433;databaseName=tp_metodologia_festival2", "sa", "123456" );
            JasperReport reporte = JasperCompileManager.compileReport("D:\\TECNICATURA\\SEGUNDO AÑO\\SEGUNDO CUATRIMESTRE\\METODOLOGIA DE SISTEMAS\\PROGRAMA\\FestivalCodigo2\\src\\Model\\reporteArtistas.jrxml");
            JasperPrint print = JasperFillManager.fillReport(reporte, NullPointerException, con);
            
            JasperViewer.viewReport(print);
         
        }
} 
